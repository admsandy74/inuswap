import React, { useEffect, useMemo, useState } from "react";
import {
  formatUnits,
  formatEther,
  parseEther,
  parseUnits,
  isAddress,
} from "viem";
import {
  ROBINHOOD_CHAIN_ID,
  getAelvoraCurveChart,
  getMarketChart,
  resolveAelvoraToken,
  getBuyQuote,
  getSellQuote,
  getV4BuyQuote,
  getV4SellQuote,
  getV3BuyQuote,
  getV3SellQuote,
  calculateMinimumReceived,
  executeCurveBuy,
  executeCurveSell,
  executeV4Buy,
  executeV4Sell,
  executeV3Buy,
  executeV3Sell,
  getTokenBalance,
  publicClient,
  getDexScreenerTokenData,
  getRecentTrades,
  getTokenHolders,
} from "./AelvoraSwap.js";
import "./swap.css";
import {
  getActiveWalletProvider,
  switchToRobinhoodChain,
} from "../wallet/wallet";

const DEMO_TRADES = [];

const DEMO_HOLDERS = [];

function MiniChart({
  tokenAddress,
  pairAddress,
}) {
  const token = String(
    tokenAddress || ""
  ).trim();

  const pair = String(
    pairAddress || ""
  ).trim();

  if (!token) {
    return (
      <div className="swap-chart-empty">
        Select a token to view the chart.
      </div>
    );
  }

  const validAddress = (value) =>
    /^0x[a-fA-F0-9]{40}$/.test(value);

  const target =
    validAddress(pair)
      ? pair
      : token;

  const chartUrl =
    `https://dexscreener.com/robinhood/${target}` +
    `?chartType=price&embed=1&info=0&theme=dark&trades=0`;

  return (
    <iframe
      key={chartUrl}
      className="swap-chart-dex"
      src={chartUrl}
      title="DexScreener Chart"
      loading="eager"
      frameBorder="0"
      allow="clipboard-write"
    />
  );
}


function Pagination({ page, totalPages, onChange }) {
  if (totalPages <= 1) return null;

  return (
    <div className="swap-pagination">
      <button
        type="button"
        disabled={page === 1}
        onClick={() => onChange(page - 1)}
      >
        ←
      </button>

      {Array.from({ length: totalPages }, (_, i) => i + 1).map((item) => (
        <button
          type="button"
          key={item}
          className={page === item ? "active" : ""}
          onClick={() => onChange(item)}
        >
          {item}
        </button>
      ))}

      <button
        type="button"
        disabled={page === totalPages}
        onClick={() => onChange(page + 1)}
      >
        →
      </button>
    </div>
  );
}

export default function SwapPage({
  onBack,
  walletAddress,
  walletChainId,
  onConnect,
  onDisconnect,
  tokenAddress,
  compact = false,
  preservePath = false,
}) {
  const walletProvider = getActiveWalletProvider();
  const [tradePage, setTradePage] = useState(1);
  const [liveTrades, setLiveTrades] = useState([]);
  const [tradesLoading, setTradesLoading] = useState(false);
  const [holderPage, setHolderPage] = useState(1);
  const [liveHolders, setLiveHolders] = useState([]);
  const [holdersLoading, setHoldersLoading] = useState(false);
  const [payAmount, setPayAmount] = useState("");
  const [swapDirection, setSwapDirection] = useState("buy");
  const [selectedToken, setSelectedToken] = useState("");
  const [tokenSearch, setTokenSearch] = useState("");
  const [savedTokens, setSavedTokens] = useState([]);
  const [tokenDropdownOpen, setTokenDropdownOpen] = useState(false);
  const [tokenData, setTokenData] = useState(null);
  const [chartData, setChartData] = useState([]);
  const [chartLoading, setChartLoading] = useState(false);
  const [chartTimeframe, setChartTimeframe] = useState("1H");
  const [tokenLoading, setTokenLoading] = useState(false);
  const [tokenError, setTokenError] = useState("");
  const [receiveAmount, setReceiveAmount] = useState("");
  const [quoteLoading, setQuoteLoading] = useState(false);
  const [quoteData, setQuoteData] = useState(null);
  const [swapLoading, setSwapLoading] = useState(false);
  const [swapError, setSwapError] = useState("");
  const [swapSuccess, setSwapSuccess] = useState("");
  const [switchingChain, setSwitchingChain] = useState(false);

  const [currentChainId, setCurrentChainId] =
    useState(walletChainId);

  useEffect(() => {
    setCurrentChainId(walletChainId);
  }, [walletChainId]);

  useEffect(() => {
    const provider = getActiveWalletProvider();

    if (!provider?.request) {
      return;
    }

    const syncChain = async () => {
      try {
        const chainId = await provider.request({
          method: "eth_chainId",
        });

        setCurrentChainId(chainId);
      } catch (err) {
        console.error(
          "Failed to detect wallet network:",
          err
        );
      }
    };

    syncChain();

    const handleChainChanged = (chainId) => {
      setCurrentChainId(chainId);
    };

    provider.on?.("chainChanged", handleChainChanged);

    return () => {
      provider.removeListener?.(
        "chainChanged",
        handleChainChanged
      );
    };
  }, [walletAddress]);


  const [ethBalance, setEthBalance] = useState(0n);
  const [tokenBalance, setTokenBalance] = useState(0n);
  const [tokenResolveLoading, setTokenResolveLoading] = useState(false);

  const ROWS_PER_PAGE = 10;
  const tokenStorageKey = (address) =>
    `AELVORA_SWAP_TOKENS_${String(address || "").toLowerCase()}`;

  const loadSavedTokens = async (address) => {
    if (!address) {
      setSavedTokens([]);
      return;
    }

    try {
      const response = await fetch(
        `/api/swap/tokens?wallet=${encodeURIComponent(address)}`
      );

      if (!response.ok) {
        throw new Error("Failed to load saved tokens.");
      }

      const data = await response.json();

      const tokens = Array.isArray(data?.tokens)
        ? data.tokens
        : [];

      setSavedTokens(tokens);
    } catch (error) {
      console.error("[AELVORA] Saved token load failed:", error);
      setSavedTokens([]);
    }
  };

  const saveToken = async (data) => {
    if (!walletAddress || !data?.token) return;

    try {
      const response = await fetch("/api/swap/tokens", {
        method: "POST",
        headers: {
          "content-type": "application/json",
        },
        body: JSON.stringify({
          wallet: walletAddress,
          token: data.token,
          symbol: data.symbol || "TOKEN",
          name: data.name || data.symbol || "TOKEN",
          decimals: Number(data.decimals ?? 18),
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to save token.");
      }

      const result = await response.json();

      setSavedTokens(
        Array.isArray(result?.tokens)
          ? result.tokens
          : []
      );
    } catch (error) {
      console.error("[AELVORA] Saved token save failed:", error);
    }
  };

  const deleteSavedToken = async (tokenAddress) => {
    if (!walletAddress || !tokenAddress) return;

    try {
      const response = await fetch(
        `/api/swap/tokens/${encodeURIComponent(tokenAddress)}?wallet=${encodeURIComponent(walletAddress)}`,
        {
          method: "DELETE",
        }
      );

      if (!response.ok) {
        throw new Error("Failed to delete token.");
      }

      const result = await response.json();

      setSavedTokens(
        Array.isArray(result?.tokens)
          ? result.tokens
          : []
      );
    } catch (error) {
      console.error("[AELVORA] Saved token delete failed:", error);
    }
  };

const updateSwapTokenUrl = (tokenAddress) => {
    const ca = String(tokenAddress || "").trim();

    if (!ca) {
      window.history.replaceState({}, "", "/swap");
      return;
    }

    const targetPath = `/swap/${ca.toLowerCase()}`;

    if (window.location.pathname !== targetPath) {
      window.history.pushState({}, "", targetPath);
    }
  };

  const loadToken = async (rawAddress = tokenSearch, updateUrl = true) => {
    const ca = String(rawAddress || "").trim();

    setTokenError("");
    setSwapError("");
    setSwapSuccess("");

    if (!ca) {
      setTokenError("Enter a token contract address.");
      return;
    }

    if (!isAddress(ca)) {
      setTokenError("Invalid token contract address.");
      return;
    }

    if (updateUrl && !preservePath) {
      updateSwapTokenUrl(ca);
    }

    setTokenResolveLoading(true);
    setTokenLoading(true);
    setTokenData(null);
    setQuoteData(null);
    setReceiveAmount("");

    try {
      const data = await resolveAelvoraToken(ca);
      setTokenData(data);
      setSelectedToken(data.symbol || "TOKEN");
      saveToken(data);
      setTokenSearch("");
    } catch (error) {
      console.error("Aelvora token resolve failed:", error);
      setTokenError(
        error?.shortMessage ||
        error?.message ||
        "Token not found."
      );
    } finally {
      setTokenResolveLoading(false);
      setTokenLoading(false);
    }
  }

  useEffect(() => {
    let cancelled = false;

    const loadChart = async () => {
      setChartLoading(true);

      try {
        if (!tokenData?.token) {
          if (!cancelled) {
            setChartData([]);
          }

          return;
        }

        /*
         * ----------------------------------------------------
         * AELVORA PRE-GRADUATION
         * ----------------------------------------------------
         * Bonding curve remains the source of truth.
         */
        if (
          tokenData.isAelvora &&
          tokenData.curve &&
          !tokenData.isGraduated
        ) {
          const points = await getAelvoraCurveChart(
            tokenData.curve
          );

          if (!cancelled) {
            setChartData(
              Array.isArray(points)
                ? points
                : []
            );
          }

          return;
        }

        /*
         * ----------------------------------------------------
         * GRADUATED AELVORA + GLOBAL TOKEN
         * ----------------------------------------------------
         * Use the market pool behind DexScreener,
         * but render the chart entirely inside AELVORA.
         */
        if (tokenData.token) {
          const points = await getMarketChart(
            tokenData.token,
            tokenData.pairAddress,
            chartTimeframe
          );

          if (!cancelled) {
            const currentPrice = Number(
              tokenData.price || 0
            );

            const historical = Array.isArray(points)
              ? points
              : [];

            /*
             * Add the current resolver price as a
             * temporary live point when available.
             *
             * This stays only in React memory.
             */
            const withCurrent =
              Number.isFinite(currentPrice) &&
              currentPrice > 0
                ? [
                    ...historical,
                    {
                      type: "LIVE",
                      timestamp: Math.floor(
                        Date.now() / 1000
                      ),
                      price: currentPrice,
                    },
                  ]
                : historical;

            const deduped = [];
            const seen = new Set();

            for (const item of withCurrent) {
              const timestamp = Number(
                item?.timestamp
              );

              const price = Number(
                item?.price
              );

              if (
                !Number.isFinite(timestamp) ||
                !Number.isFinite(price) ||
                price <= 0
              ) {
                continue;
              }

              const key =
                `${timestamp}:${price}`;

              if (seen.has(key)) {
                continue;
              }

              seen.add(key);

              deduped.push({
                type:
                  item?.type || "MARKET",
                timestamp,
                price,
              });
            }

            deduped.sort(
              (a, b) =>
                Number(a.timestamp) -
                Number(b.timestamp)
            );

            setChartData(deduped);
          }

          return;
        }

        /*
         * No market pool available.
         * Do not fabricate chart history.
         */
        if (!cancelled) {
          setChartData([]);
        }
      } catch (error) {
        console.error(
          "[AELVORA] Chart load failed:",
          error
        );

        if (!cancelled) {
          setChartData([]);
        }
      } finally {
        if (!cancelled) {
          setChartLoading(false);
        }
      }
    };

    loadChart();

    return () => {
      cancelled = true;
    };
  }, [
    tokenData?.token,
    tokenData?.curve,
    tokenData?.pairAddress,
    tokenData?.isAelvora,
    tokenData?.isGraduated,
    tokenData?.price,
    chartTimeframe,
  ]);


  const filteredChartData = useMemo(() => {
    const source = Array.isArray(chartData)
      ? chartData
          .filter(
            (item) =>
              Number.isFinite(Number(item?.price)) &&
              Number(item.price) > 0 &&
              Number.isFinite(Number(item?.timestamp))
          )
          .sort(
            (a, b) =>
              Number(a.timestamp) -
              Number(b.timestamp)
          )
      : [];

    if (!source.length) {
      return [];
    }

    const timeframeSeconds = {
      "5m": 5 * 60,
      "15m": 15 * 60,
      "1H": 60 * 60,
      "4H": 4 * 60 * 60,
      "1D": 24 * 60 * 60,
    };

    const seconds =
      timeframeSeconds[chartTimeframe] ||
      timeframeSeconds["1H"];

    const latestTimestamp = Number(
      source[source.length - 1].timestamp
    );

    const cutoff =
      latestTimestamp - seconds;

    const filtered = source.filter(
      (item) =>
        Number(item.timestamp) >= cutoff
    );

    if (!filtered.length) {
      return [source[source.length - 1]];
    }

    return filtered;
  }, [chartData, chartTimeframe]);

  const handleTokenSearchKeyDown = (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      loadToken();
    }
  };
;

  useEffect(() => {
    let cancelled = false;

    const restoreSavedTokens = async () => {
      if (!walletAddress) {
        if (!cancelled) {
          setSavedTokens([]);
        }
        return;
      }

      try {
        const response = await fetch(
          `/api/swap/tokens?wallet=${encodeURIComponent(walletAddress)}`
        );

        if (!response.ok) {
          throw new Error("Failed to load saved tokens.");
        }

        const data = await response.json();
        const tokens = Array.isArray(data?.tokens)
          ? data.tokens
          : [];

        if (!cancelled) {
          setSavedTokens(tokens);
        }
      } catch (error) {
        console.error("[AELVORA] Saved token restore failed:", error);

        if (!cancelled) {
          setSavedTokens([]);
        }
      }
    };

    restoreSavedTokens();

    return () => {
      cancelled = true;
    };
  }, [walletAddress]);


  useEffect(() => {
    if (tokenAddress) {
      setTokenSearch(tokenAddress);
      loadToken(tokenAddress, false);
      return;
    }

    const parts = window.location.pathname.split("/").filter(Boolean);
    const ca =
      parts[0] === "swap" && parts[1]
        ? parts[1]
        : "";

    if (ca) {
      setTokenSearch(ca);
      loadToken(ca, false);
    }
  }, [tokenAddress]);

  const refreshBalances = async () => {
    if (!walletAddress || !isAddress(walletAddress)) {
      setEthBalance(0n);
      setTokenBalance(0n);
      return;
    }

    try {
      const eth = await publicClient.getBalance({
        address: walletAddress,
      });

      setEthBalance(eth);

      if (tokenData?.token) {
        const token = await getTokenBalance(
          tokenData.token,
          walletAddress
        );

        setTokenBalance(token);
      } else {
        setTokenBalance(0n);
      }
    } catch (error) {
      console.error("Wallet balance lookup failed:", error);
      setEthBalance(0n);
      setTokenBalance(0n);
    }
  };

  useEffect(() => {
    let cancelled = false;

    const run = async () => {
      if (cancelled) return;
      await refreshBalances();
    };

    run();

    return () => {
      cancelled = true;
    };
  }, [walletAddress, tokenData]);


  useEffect(() => {
    if (
      !tokenData ||
      !payAmount ||
      Number(payAmount) <= 0
    ) {
      setReceiveAmount("");
      setQuoteData(null);
      setQuoteLoading(false);
      return;
    }

    let cancelled = false;

    setQuoteLoading(true);
    setSwapError("");
    setSwapSuccess("");

    const runQuote = async () => {
      try {
        let quote;

        if (swapDirection === "buy") {
          const ethWei = parseEther(payAmount);

          if (tokenData.isAelvora && !tokenData.isGraduated) {
            quote = await getBuyQuote(
              tokenData.curve,
              ethWei
            );

          } else if (
            tokenData.isAelvora &&
            tokenData.isGraduated
          ) {
            quote = await getV4BuyQuote(
              tokenData.token,
              ethWei,
              tokenData.v4Pool
            );

          } else if (
            tokenData.isGlobal &&
            tokenData.routeType === "v4"
          ) {
            quote = await getV4BuyQuote(
              tokenData.token,
              ethWei,
              tokenData.v4Pool
            );

          } else if (
            tokenData.isGlobal &&
            tokenData.routeType === "v3"
          ) {
            quote = await getV3BuyQuote(
              tokenData.token,
              ethWei
            );

          } else {
            throw new Error(
              "No supported swap route found for this token."
            );
          }

        } else {
          const tokenWei = parseUnits(
            payAmount,
            Number(tokenData.decimals || 18)
          );

          if (tokenData.isAelvora && !tokenData.isGraduated) {
            quote = await getSellQuote(
              tokenData.curve,
              tokenWei
            );

          } else if (
            tokenData.isAelvora &&
            tokenData.isGraduated
          ) {
            quote = await getV4SellQuote(
              tokenData.token,
              tokenWei,
              tokenData.v4Pool
            );

          } else if (
            tokenData.isGlobal &&
            tokenData.routeType === "v4"
          ) {
            quote = await getV4SellQuote(
              tokenData.token,
              tokenWei,
              tokenData.v4Pool
            );

          } else if (
            tokenData.isGlobal &&
            tokenData.routeType === "v3"
          ) {
            quote = await getV3SellQuote(
              tokenData.token,
              tokenWei
            );

          } else {
            throw new Error(
              "No supported swap route found for this token."
            );
          }
        }

        if (cancelled) return;

        const decimals =
          swapDirection === "buy"
            ? Number(tokenData.decimals || 18)
            : 18;

        const amountOut =
          quote.amountOut ??
          quote.tokensOut ??
          quote.ethToSeller ??
          quote.ethGross ??
          0n;

        const minimumReceived =
          quote.minimumReceived ??
          calculateMinimumReceived(amountOut);

        setQuoteData({
          ...quote,
          amountOut,
          minimumReceived,
          decimals,
        });

        setReceiveAmount(
          Number(
            formatUnits(amountOut, decimals)
          ).toLocaleString("en-US", {
            maximumFractionDigits: 6,
          })
        );
      } catch (error) {
        if (!cancelled) {
          console.error("Quote failed:", error);
          setReceiveAmount("");
          setQuoteData(null);
          const errorMessage =
            error?.shortMessage ||
            error?.message ||
            "Quote failed";

          const displayError =
            errorMessage.includes("No supported swap route found")
              ? "Token not supported for swap"
              : errorMessage;

          console.log("[AELVORA] Swap UI error:", displayError);

          setSwapError(displayError);
        }
      } finally {
        if (!cancelled) {
          setQuoteLoading(false);
        }
      }
    };

    runQuote();

    return () => {
      cancelled = true;
    };
  }, [payAmount, tokenData, swapDirection]);


  const displayPrice = tokenData
    ? Number(tokenData.price || 0).toLocaleString("en-US", {
        maximumFractionDigits: 12,
      })
    : "0.000123";

  const minimumReceivedDisplay =
    quoteData && tokenData
      ? Number(
          formatUnits(
            quoteData.minimumReceived,
            swapDirection === "buy"
              ? tokenData.decimals
              : 18
          )
        ).toLocaleString("en-US", {
          maximumFractionDigits: 6,
        })
      : "--";

  const routeDisplay = !tokenData
    ? "--"
    : tokenData.isAelvora
      ? tokenData.isGraduated
        ? "Uniswap V4"
        : "Bonding Curve"
      : "Uniswap V3";

  const estimatedGasDisplay =
    quoteData?.gasEstimate
      ? quoteData.gasEstimate.toLocaleString("en-US")
      : "--";

  const ethBalanceDisplay = walletAddress
    ? Number(formatEther(ethBalance)).toLocaleString("en-US", {
        maximumFractionDigits: 6,
      })
    : "--";

  const tokenBalanceDisplay =
    walletAddress && tokenData
      ? Number(
          formatUnits(
            tokenBalance,
            Number(tokenData.decimals || 18)
          )
        ).toLocaleString("en-US", {
          maximumFractionDigits: 6,
        })
      : "--";

  const isSell = swapDirection === "sell";
  const setMaxEthAmount = () => {
    if (!walletAddress || ethBalance <= 0n) {
      setPayAmount("");
      return;
    }

    const gasReserve = 1_000_000_000_000n;
    const amount =
      ethBalance > gasReserve
        ? ethBalance - gasReserve
        : 0n;

    setPayAmount(amount > 0n ? formatEther(amount) : "");
  };

  const setMaxTokenAmount = () => {
    if (!tokenData || tokenBalance <= 0n) {
      setPayAmount("");
      return;
    }

    // Keep a small buffer on SELL to avoid bonding-curve
    // rounding/liquidity edge cases when selling the full balance.
    const sellAmount = (tokenBalance * 99n) / 100n;

    setPayAmount(
      formatUnits(
        sellAmount,
        Number(tokenData.decimals || 18)
      )
    );
  };

  const toggleSwapDirection = () => {
    setSwapDirection((current) =>
      current === "buy" ? "sell" : "buy"
    );
    setPayAmount("");
    setReceiveAmount("");
    setQuoteData(null);
    setSwapError("");
    setSwapSuccess("");
  };

  const executeSwap = async () => {
    if (!walletAddress || !walletProvider) {
      onConnect?.();
      return;
    }

    const normalizedWalletChainId =
      typeof walletChainId === "string"
        ? Number(walletChainId)
        : Number(walletChainId);

    if (
      !Number.isFinite(normalizedWalletChainId) ||
      normalizedWalletChainId !== Number(ROBINHOOD_CHAIN_ID)
    ) {
      setSwapError(
        "Please switch your wallet to Robinhood Chain."
      );
      return;
    }

    if (
      !tokenData ||
      !payAmount ||
      Number(payAmount) <= 0
    ) {
      setSwapError(
        isSell
          ? "Enter a token amount first."
          : "Enter an ETH amount first."
      );
      return;
    }

    if (!quoteData) {
      setSwapError("Quote is not available yet.");
      return;
    }

    setSwapLoading(true);
    setSwapError("");
    setSwapSuccess("");

    try {
      let txHash;

      if (!isSell) {
        const ethWei = parseEther(payAmount);

        if (
          tokenData.isAelvora &&
          !tokenData.isGraduated
        ) {
          txHash = await executeCurveBuy({
            provider: walletProvider,
            account: walletAddress,
            curveAddress: tokenData.curve,
            ethGross: ethWei,
          });
        } else if (
          tokenData.isAelvora &&
          tokenData.isGraduated
        ) {
          txHash = await executeV4Buy({
            provider: walletProvider,
            account: walletAddress,
            tokenAddress: tokenData.token,
            ethGross: ethWei,
            minimumReceived:
              quoteData.minimumReceived,
          });
        } else {
          txHash = await executeV3Buy({
            provider: walletProvider,
            account: walletAddress,
            tokenAddress: tokenData.token,
            ethGross: ethWei,
            minimumReceived:
              quoteData.minimumReceived,
          });
        }
      } else {
        const tokenWei = parseUnits(
          payAmount,
          Number(tokenData.decimals || 18)
        );

        if (
          tokenData.isAelvora &&
          !tokenData.isGraduated
        ) {
          txHash = await executeCurveSell({
            provider: walletProvider,
            account: walletAddress,
            tokenAddress: tokenData.token,
            curveAddress: tokenData.curve,
            tokenAmount: tokenWei,
          });
        } else if (
          tokenData.isAelvora &&
          tokenData.isGraduated
        ) {
          txHash = await executeV4Sell({
            provider: walletProvider,
            account: walletAddress,
            tokenAddress: tokenData.token,
            tokenAmount: tokenWei,
            minimumReceived:
              quoteData.minimumReceived,
          });
        } else {
          txHash = await executeV3Sell({
            provider: walletProvider,
            account: walletAddress,
            tokenAddress: tokenData.token,
            tokenAmount: tokenWei,
            minimumReceived:
              quoteData.minimumReceived,
          });
        }
      }

      await publicClient.waitForTransactionReceipt({
        hash: txHash,
      });

      await refreshBalances();

      setSwapSuccess(
        `Transaction confirmed: ${txHash.slice(
          0,
          10
        )}...${txHash.slice(-8)}`
      );

      setPayAmount("");
      setReceiveAmount("");
      setQuoteData(null);
    } catch (error) {
      console.error("Swap failed:", error);
      setSwapError(
        error?.shortMessage ||
        error?.message ||
        "Swap failed"
      );
    } finally {
      setSwapLoading(false);
    }
  };


  useEffect(() => {
    let cancelled = false;

    const loadHolders = async () => {
      const token = tokenData?.token;

      if (!token) {
        if (!cancelled) {
          setLiveHolders([]);
          setHolderPage(1);
          setHoldersLoading(false);
        }
        return;
      }

      if (!cancelled) {
        setHoldersLoading(true);
        setHolderPage(1);
      }

      try {
        const holders = await getTokenHolders(token, 50);

        if (!cancelled) {
          setLiveHolders(
            Array.isArray(holders)
              ? holders
              : []
          );
        }
      } catch (error) {
        console.error(
          "[AELVORA] Live holders load failed:",
          error
        );

        if (!cancelled) {
          setLiveHolders([]);
        }
      } finally {
        if (!cancelled) {
          setHoldersLoading(false);
        }
      }
    };

    loadHolders();

    return () => {
      cancelled = true;
    };
  }, [tokenData?.token]);

  useEffect(() => {
    let cancelled = false;
    let timer = null;
    let loading = false;

    const loadLiveTrades = async () => {
      const token = tokenData?.token;

      if (!token) {
        if (!cancelled) {
          setLiveTrades([]);
          setTradesLoading(false);
        }
        return;
      }

      if (loading) {
        return;
      }

      loading = true;

      try {
        if (!liveTrades.length && !cancelled) {
          setTradesLoading(true);
        }

        const trades = await getRecentTrades(
          token,
          50
        );

        if (!cancelled) {
          setLiveTrades(
            Array.isArray(trades)
              ? trades
              : []
          );
        }
      } catch (error) {
        console.error(
          "[AELVORA] Live trades load failed:",
          error
        );
      } finally {
        loading = false;

        if (!cancelled) {
          setTradesLoading(false);
        }
      }
    };

    loadLiveTrades();

    // Refresh every 15 seconds.
    // Prevent overlapping RPC scans.
    timer = setInterval(
      loadLiveTrades,
      15000
    );

    return () => {
      cancelled = true;

      if (timer) {
        clearInterval(timer);
      }
    };
  }, [tokenData?.token]);

  const tradePages = Math.min(
    5,
    Math.max(
      1,
      Math.ceil(liveTrades.length / ROWS_PER_PAGE)
    )
  );
  const holderPages = Math.max(
    1,
    Math.ceil(liveHolders.length / ROWS_PER_PAGE)
  );

  const visibleTrades = useMemo(
    () =>
      liveTrades
        .slice(0, 50)
        .slice(
          (tradePage - 1) * ROWS_PER_PAGE,
          tradePage * ROWS_PER_PAGE
        ),
    [liveTrades, tradePage]
  );

  const visibleHolders = useMemo(
    () =>
      liveHolders.slice(
        (holderPage - 1) * ROWS_PER_PAGE,
        holderPage * ROWS_PER_PAGE
      ),
    [liveHolders, holderPage]
  );

  const networkSwitchButton = (
    <button
      type="button"
      disabled={switchingChain}
      onClick={async () => {
        const provider =
          getActiveWalletProvider();

        if (!provider || switchingChain) {
          return;
        }

        try {
          setSwitchingChain(true);

          const chainId =
            await switchToRobinhoodChain(provider);

          setCurrentChainId(chainId);

          if (
            Number(chainId) ===
            Number(ROBINHOOD_CHAIN_ID)
          ) {
            window.dispatchEvent(
              new CustomEvent(
                "aelvora:wallet-chain-changed",
                {
                  detail: { chainId },
                }
              )
            );
          }
        } catch (err) {
          console.error(
            "Failed to switch network:",
            err
          );
        } finally {
          setSwitchingChain(false);
        }
      }}
    >
      {switchingChain
        ? "Switching..."
        : "Switch to Robinhood Chain"}
    </button>
  );

  const networkNotice = (
    <div className="swap-network-notice">
      {networkSwitchButton}
    </div>
  );

  return (
    <div className={`swap-page${compact ? " swap-page-compact" : ""}`}>
      {compact &&
        Boolean(walletAddress) &&
        Number(currentChainId) !== Number(ROBINHOOD_CHAIN_ID) && (
          <div className="swap-network-notice">
            {networkSwitchButton}
          </div>
        )}
      {!compact && (
        <header className="swap-navbar">
        <button
          type="button"
          className="swap-brand"
          onClick={onBack}
          aria-label="AELVORA"
        >
          <img
            src="/assets/logo-icon.svg"
            alt=""
            className="swap-brand-logo"
          />

          <span className="swap-brand-wordmark">
            <strong>AELVORA</strong>
            <small>APP</small>
          </span>
        </button>

        <div className="swap-nav-right">
          {Boolean(walletAddress) &&
            Number(currentChainId) !== Number(ROBINHOOD_CHAIN_ID) && (
              <div className="swap-navbar-network-notice">
                {networkSwitchButton}
              </div>
            )}

          {walletAddress ? (
            <div className="swap-wallet-actions">
              <span className="swap-wallet-short">
                {walletAddress.slice(0, 6)}...
                {walletAddress.slice(-4)}
              </span>

              <button
                type="button"
                className="swap-disconnect-top"
                onClick={onDisconnect}
              >
                Disconnect
              </button>
            </div>
          ) : (
            <button
              type="button"
              className="swap-connect-top"
              onClick={onConnect}
            >
              Connect Wallet
            </button>
          )}
        </div>
        </header>
      )}

      <main className="swap-main">
        {!compact && (
          <button type="button" className="swap-back-home" onClick={onBack}>
            ← Back to Home
          </button>
        )}

        {!compact && (
          <div className="swap-token-heading">
            <div>
              <span className="swap-eyebrow">AELVORA SWAP</span>
              <h1>
                {selectedToken ? `$${selectedToken}` : "$TOKEN"} <span>/ ETH</span>
              </h1>
            </div>

            <div className="swap-price">
              <small>Price</small>
              <strong>{tokenData ? `${displayPrice} ETH` : "$0.000123"}</strong>
            </div>
          </div>
        )}

        <section className="swap-top-grid">
          {!compact && (
            <div className="swap-chart-card">
              <div className="swap-chart-header">
              <div>
                <span>Price</span>
                <strong>{tokenData ? `${displayPrice} ETH` : "$0.000123"}</strong>
              </div>

              
            </div>

            <div className="swap-chart">
              <MiniChart
                tokenAddress={tokenData?.token}
                pairAddress={tokenData?.pairAddress}
              />
              </div>
            </div>
          )}

          <aside className="swap-card">
            <div className="swap-card-title">
              <span>Swap</span>
              <span className="swap-network">ROBINHOOD</span>
            </div>

            <label className="swap-field-label">
              You pay
            </label>

            <div className="swap-field">
              <input
                type="number"
                min="0"
                step="any"
                placeholder="0.00"
                value={payAmount}
                onChange={(e) =>
                  setPayAmount(e.target.value)
                }
              />

              {isSell ? (
                <>
                  <button
                    type="button"
                    className="swap-token-select"
                    disabled={!savedTokens.length}
                    onClick={(event) => {
                      event.stopPropagation();
                      setTokenDropdownOpen((open) => !open);
                    }}
                    title={
                      savedTokens.length
                        ? "Saved tokens"
                        : "No saved tokens"
                    }
                  >
                    {selectedToken || "Select token"} <span>▼</span>
                  </button>

                  <button
                    type="button"
                    className="swap-token-select"
                    onClick={setMaxTokenAmount}
                    disabled={!tokenBalance || tokenBalance <= 0n}
                    title="Use available token balance"
                  >
                    <span className="swap-max-label">MAX</span>
                  </button>

                  {tokenDropdownOpen && savedTokens.length > 0 && (
                    <div
                      className="swap-saved-token-menu"
                      onClick={(event) => event.stopPropagation()}
                    >
                      {savedTokens.map((saved) => (
                        <div
                          key={saved.token}
                          className="swap-saved-token-row"
                        >
                          <button
                            type="button"
                            className="swap-saved-token-main"
                            onClick={() => {
                              setTokenDropdownOpen(false);
                              loadToken(saved.token);
                            }}
                          >
                            <span className="swap-saved-token-symbol">
                              {saved.symbol || "TOKEN"}
                            </span>

                            <span className="swap-saved-token-address">
                              {saved.token.slice(0, 6)}...
                              {saved.token.slice(-4)}
                            </span>
                          </button>

                          <button
                            type="button"
                            className="swap-saved-token-delete"
                            aria-label={`Delete ${saved.symbol || "token"}`}
                            title="Remove saved token"
                            onClick={() => {
                              deleteSavedToken(saved.token);
                            }}
                          >
                            ×
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </>
              ) : (
                <button
                  type="button"
                  className="swap-token-select"
                  onClick={setMaxEthAmount}
                  title="Use available ETH balance"
                >
                  ETH <span className="swap-max-label">MAX</span>
                </button>
              )}
              
            </div>

            <div className="swap-balance">
              <span>
                {isSell
                  ? `${selectedToken || "TOKEN"} balance`
                  : "ETH balance"}
              </span>

              <strong>
                {!walletAddress
                  ? "--"
                  : isSell
                    ? tokenBalance > 0n
                      ? `${tokenBalanceDisplay} ${selectedToken}`
                      : "No balance"
                    : `${ethBalanceDisplay} ETH`}
              </strong>
            </div>

            <div className="swap-switch">
              <button
                type="button"
                aria-label="Switch tokens"
                onClick={toggleSwapDirection}
                disabled={!tokenData}
              >
                ⇅
              </button>
            </div>

            <label className="swap-field-label">
              You receive
            </label>

            <div className="swap-field">
              <input
                type="text"
                placeholder="0.00"
                className={swapError ? "swap-input-invalid" : ""}
                value={
                  quoteLoading
                    ? "Loading..."
                    : swapError
                      ? "Invalid"
                      : receiveAmount
                }
                readOnly
              />

              {isSell ? (
                <button
                  type="button"
                  className="swap-token-select"
                  disabled
                >
                  ETH
                </button>
              ) : (
                <>
                  <button
                    type="button"
                    className="swap-token-select"
                    disabled={!savedTokens.length}
                    onClick={(event) => {
                      event.stopPropagation();
                      setTokenDropdownOpen((open) => !open);
                    }}
                    title={
                      savedTokens.length
                        ? "Saved tokens"
                        : "No saved tokens"
                    }
                  >
                    {selectedToken || "Select token"} <span>▼</span>
                  </button>

                  {tokenDropdownOpen && savedTokens.length > 0 && (
                    <div
                      className="swap-saved-token-menu"
                      onClick={(event) => event.stopPropagation()}
                    >
                      {savedTokens.map((saved) => (
                        <div
                          key={saved.token}
                          className="swap-saved-token-row"
                        >
                          <button
                            type="button"
                            className="swap-saved-token-main"
                            onClick={() => {
                              setTokenDropdownOpen(false);
                              loadToken(saved.token);
                            }}
                          >
                            <span className="swap-saved-token-symbol">
                              {saved.symbol || "TOKEN"}
                            </span>

                            <span className="swap-saved-token-address">
                              {saved.token.slice(0, 6)}...
                              {saved.token.slice(-4)}
                            </span>
                          </button>

                          <button
                            type="button"
                            className="swap-saved-token-delete"
                            aria-label={`Delete ${saved.symbol || "token"}`}
                            title="Remove saved token"
                            onClick={() => {
                              deleteSavedToken(saved.token);
                            }}
                          >
                            ×
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </>
              )}
            </div>

            <div className="swap-balance">
              <span>
                {isSell
                  ? "ETH balance"
                  : `${selectedToken || "TOKEN"} balance`}
              </span>

              <strong>
                {!walletAddress
                  ? "--"
                  : isSell
                    ? `${ethBalanceDisplay} ETH`
                    : tokenBalance > 0n
                      ? `${tokenBalanceDisplay} ${selectedToken}`
                      : "No balance"}
              </strong>
            </div>

            <div className="swap-token-search">
              <input
                type="text"
                placeholder="Token contract address"
                value={tokenSearch}
                onChange={(e) =>
                  setTokenSearch(e.target.value)
                }
                onKeyDown={handleTokenSearchKeyDown}
              />

              <button
                type="button"
                className="swap-token-search-button"
                onClick={() => loadToken()}
                disabled={tokenResolveLoading}
              >
                {tokenResolveLoading
                  ? "Loading..."
                  : "Add Token"}
              </button>
            </div>

            {tokenLoading && (
              <div className="swap-live-status">
                Adding token...
              </div>
            )}

            {tokenError && (
              <div className="swap-live-error">
                {tokenError}
              </div>
            )}

            {tokenData && (
              <div className="swap-live-status">
                {tokenData.isAelvora
                  ? tokenData.isGraduated
                    ? "Graduated • Uniswap V4"
                    : `Bonding Curve • ${tokenData.ethReserveFormatted} ETH reserve`
                  : `External Token • Uniswap V3`}
              </div>
            )}

            <div className="swap-details">
              <div>
                <span>Route</span>
                <strong>{routeDisplay}</strong>
              </div>

              <div>
                <span>Minimum received</span>
                <strong>{minimumReceivedDisplay}</strong>
              </div>

              <div>
                <span>Network estimate</span>
                <strong>{estimatedGasDisplay}</strong>
              </div>
            </div>

            {swapError && (
              <div className="swap-live-error">
                {swapError}
              </div>
            )}

            {swapSuccess && (
              <div className="swap-live-status">
                {swapSuccess}
              </div>
            )}

            {walletAddress ? (
              <button
                type="button"
                className="swap-main-button"
                onClick={executeSwap}
                disabled={
                  swapLoading ||
                  quoteLoading ||
                  !tokenData ||
                  !quoteData ||
                  (isSell && tokenBalance <= 0n)
                }
              >
                {swapLoading
                  ? "Confirming..."
                  : quoteLoading
                    ? "Getting quote..."
                    : isSell
                      ? `Sell ${selectedToken || "TOKEN"}`
                      : `Buy ${selectedToken || "TOKEN"}`}
              </button>
            ) : (
              <button
                type="button"
                className="swap-main-button"
                onClick={onConnect}
              >
                Connect Wallet
              </button>
            )}

            <p className="swap-note">
              {tokenData?.isGlobal
                ? "Mainnet Swap is Live"
                : tokenData?.isGraduated
                  ? "Graduated token routes through AELVORA Router → Uniswap V4."
                  : "Token is still trading on the AELVORA bonding curve."}
            </p>
          </aside>
        </section>

        {!compact && (
          <section className="swap-data-grid">
            <div className="swap-data-card">
            <div className="swap-data-heading">
              <div>
                <span className="swap-eyebrow">ACTIVITY</span>
                <h2>Recent Trades</h2>
              </div>
              <span className="swap-count">10 / page</span>
            </div>

            <div className="swap-table-wrap">
              <table className="swap-table">
                <thead>
                  <tr>
                    <th>Type</th>
                    <th>Wallet</th>
                    <th>ETH</th>
                    <th>Tokens</th>
                  </tr>
                </thead>
                <tbody>
                  {tradesLoading && visibleTrades.length === 0 ? (
                    <tr>
                      <td colSpan="4">Loading live trades...</td>
                    </tr>
                  ) : visibleTrades.length === 0 ? (
                    <tr>
                      <td colSpan="4">No trades yet.</td>
                    </tr>
                  ) : (
                    visibleTrades.map((trade, index) => (
                      <tr
                        key={`${trade.txHash || trade.wallet}-${index}`}
                      >
                        <td>
                          <span
                            className={`swap-trade-type ${trade.type.toLowerCase()}`}
                          >
                            {trade.type}
                          </span>
                        </td>
                        <td>{trade.wallet}</td>
                        <td>{trade.amount}</td>
                        <td>{trade.tokens}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            <Pagination
              page={tradePage}
              totalPages={tradePages}
              onChange={setTradePage}
            />
          </div>

          <div className="swap-data-card">
            <div className="swap-data-heading">
              <div>
                <span className="swap-eyebrow">OWNERSHIP</span>
                <h2>Recent Holders</h2>
              </div>
              <span className="swap-count">10 / page</span>
            </div>

            <div className="swap-table-wrap">
              <table className="swap-table">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Wallet</th>
                    <th>Balance</th>
                    <th>Share</th>
                  </tr>
                </thead>
                <tbody>
                  {holdersLoading ? (
                    <tr>
                      <td colSpan="4">Loading holders...</td>
                    </tr>
                  ) : visibleHolders.length ? (
                    visibleHolders.map((holder) => (
                      <tr key={holder.address || holder.rank}>
                        <td>{holder.rank}</td>
                        <td>{holder.wallet}</td>
                        <td>{holder.amount}</td>
                        <td>{holder.share}</td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan="4">No holders found.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

              <Pagination
                page={holderPage}
                totalPages={holderPages}
                onChange={setHolderPage}
              />
            </div>
          </section>
        )}
      </main>
    </div>
  );
}
