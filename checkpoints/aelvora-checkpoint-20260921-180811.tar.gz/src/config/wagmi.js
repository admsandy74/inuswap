import { createConfig, http } from "wagmi";
import { defineChain } from "viem";
import { injected } from "wagmi/connectors";

export const robinhoodChain = defineChain({
  id: 4663,
  name: "Robinhood Chain",
  nativeCurrency: {
    name: "Ether",
    symbol: "ETH",
    decimals: 18,
  },
  rpcUrls: {
    default: {
      http: [
        "https://rpc.mainnet.chain.robinhood.com",
      ],
    },
  },
  blockExplorers: {
    default: {
      name: "Robinhood Chain Explorer",
      url: "https://robinhoodchain.blockscout.com",
    },
  },
});

export const wagmiConfig = createConfig({
  chains: [robinhoodChain],

  connectors: [
    injected({
      shimDisconnect: true,
    }),
  ],

  transports: {
    [robinhoodChain.id]: http(
      "https://rpc.mainnet.chain.robinhood.com"
    ),
  },

  multiInjectedProviderDiscovery: true,
});
