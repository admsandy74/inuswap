const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("AELVORA Creator Fee Accounting", function () {
  let owner;
  let creatorA;
  let creatorB;
  let launchWallet;
  let tradingWallet;

  let vault;
  let factory;
  let poolManager;

  const LAUNCH_FEE = ethers.parseEther("0.0003");
  const FIRST_BUY_ETH = ethers.parseEther("0.001");

  beforeEach(async function () {
    [
      owner,
      creatorA,
      creatorB,
      launchWallet,
      tradingWallet,
    ] = await ethers.getSigners();

    // ------------------------------------------------------------
    // Deploy Factory
    // Factory otomatis membuat CreatorFeeVault.
    // ------------------------------------------------------------
      // Deploy real Uniswap V4 PoolManager for local migration test.
      const PoolManager = await ethers.getContractFactory("TestPoolManager");
      poolManager = await PoolManager.deploy(owner.address);
      await poolManager.waitForDeployment();

    const Factory = await ethers.getContractFactory(
      "AelvoraFactory"
    );

      factory = await Factory.deploy(
        launchWallet.address,
        tradingWallet.address,
        await poolManager.getAddress(),
        owner.address
      );

    await factory.waitForDeployment();

    // Ambil address Vault yang dibuat Factory.
    const vaultAddress = await factory.creatorFeeVault();

    vault = await ethers.getContractAt(
      "AelvoraCreatorFeeVault",
      vaultAddress
    );
  });

  async function fundCurve(curveAddress) {
    await ethers.provider.send("hardhat_setBalance", [
      curveAddress,
      ethers.toBeHex(ethers.parseEther("1")),
    ]);
  }

  async function createToken(
    creator,
    name,
    symbol,
    creatorTaxBps = 200
  ) {
    // Mandatory creator first-buy.
    // This ETH is sent through the bonding curve:
    //   1%  -> platform
    //   creator tax -> CreatorFeeVault
    //   remainder -> real curve ETH reserve
    //
    // The resulting tokens are automatically sent
    // to the creator by Factory -> BondingCurve.buyFor().
    const FIRST_BUY_ETH =
      ethers.parseEther("0.001");

    const totalSupply =
      ethers.parseUnits("100000", 18);

    const tx = await factory.connect(creator).createToken(
      name,
      symbol,
      totalSupply,
      creatorTaxBps,
      FIRST_BUY_ETH,
      {
        value: LAUNCH_FEE + FIRST_BUY_ETH,
      }
    );

    const receipt = await tx.wait();

    const event = receipt.logs
      .map((log) => {
        try {
          return factory.interface.parseLog(log);
        } catch {
          return null;
        }
      })
      .find(
        (event) => event && event.name === "TokenCreated"
      );

    return {
      token: event.args.token,
      creator: event.args.creator,
      curve: event.args.curve,
    };
  }

  it("deploys Factory with its own CreatorFeeVault", async function () {
    expect(await vault.factory()).to.equal(
      await factory.getAddress()
    );
  });

  it("uses connected wallet as creator", async function () {
    const token = await createToken(
      creatorA,
      "Creator A Token",
      "CAT"
    );

    expect(token.creator).to.equal(
      creatorA.address
    );

    expect(
      await vault.curveCreator(token.curve)
    ).to.equal(creatorA.address);
  });

  it("keeps two tokens from the same creator completely separate", async function () {
    const tokenA = await createToken(
      creatorA,
      "Token A",
      "TKA"
    );

    const tokenB = await createToken(
      creatorA,
      "Token B",
      "TKB"
    );

    // Simulasikan fee Token A.
    await factory
      .connect(owner)
      .creatorFeeVault();

    await ethers.provider.send("hardhat_setBalance", [
      await vault.getAddress(),
      ethers.toBeHex(
        ethers.parseEther("10")
      ),
    ]);

    // Hanya curve yang terdaftar boleh accrue.
    await ethers.provider.send("hardhat_impersonateAccount", [
      tokenA.curve,
    ]);

    await fundCurve(tokenA.curve);

    const curveA = await ethers.getSigner(
      tokenA.curve
    );

    await vault
      .connect(curveA)
      .accrueCreatorFee(
        tokenA.token,
        creatorA.address,
        {
          value: ethers.parseEther("0.10"),
        }
      );

    await ethers.provider.send("hardhat_stopImpersonatingAccount", [
      tokenA.curve,
    ]);

    // createToken() already performed mandatory first-buy:
    // 0.001 ETH * 2% = 0.00002 ETH.
    //
    // Then this test manually accrues another 0.10 ETH.
    expect(
      await vault.claimable(
        tokenA.token,
        creatorA.address
      )
    ).to.equal(
      ethers.parseEther("0.10002")
    );

    // Token B has its own independent accounting bucket.
    // It was also created by creatorA, so its mandatory
    // first-buy generated its own 0.00002 ETH creator fee.
    //
    // Token A = 0.10002 ETH
    // Token B = 0.00002 ETH
    //
    // The important property is that Token B's fee does not
    // appear inside Token A's accounting.
    expect(
      await vault.claimable(
        tokenB.token,
        creatorA.address
      )
    ).to.equal(
      ethers.parseEther("0.00002")
    );
  });

  it("different creators have separate accounting", async function () {
    const tokenA = await createToken(
      creatorA,
      "Token A",
      "TKA"
    );

    const tokenB = await createToken(
      creatorB,
      "Token B",
      "TKB"
    );

    await ethers.provider.send("hardhat_setBalance", [
      await vault.getAddress(),
      ethers.toBeHex(
        ethers.parseEther("10")
      ),
    ]);

    await ethers.provider.send("hardhat_impersonateAccount", [
      tokenA.curve,
    ]);

    await fundCurve(tokenA.curve);

    const curveA = await ethers.getSigner(
      tokenA.curve
    );

    await vault
      .connect(curveA)
      .accrueCreatorFee(
        tokenA.token,
        creatorA.address,
        {
          value: ethers.parseEther("0.20"),
        }
      );

    await ethers.provider.send("hardhat_stopImpersonatingAccount", [
      tokenA.curve,
    ]);

    await ethers.provider.send("hardhat_impersonateAccount", [
      tokenB.curve,
    ]);

    await fundCurve(tokenB.curve);

    const curveB = await ethers.getSigner(
      tokenB.curve
    );

    await vault
      .connect(curveB)
      .accrueCreatorFee(
        tokenB.token,
        creatorB.address,
        {
          value: ethers.parseEther("0.30"),
        }
      );

    await ethers.provider.send("hardhat_stopImpersonatingAccount", [
      tokenB.curve,
    ]);

    // Token A received 0.00002 ETH creator fee
    // from its mandatory first-buy, plus 0.20 ETH
    // manually accrued in this test.
    expect(
      await vault.claimable(
        tokenA.token,
        creatorA.address
      )
    ).to.equal(
      ethers.parseEther("0.20002")
    );

    expect(
      await vault.claimable(
        tokenB.token,
        creatorB.address
      )
    ).to.equal(
      ethers.parseEther("0.30002")
    );

    // Cross-claim tidak boleh ada.
    expect(
      await vault.claimable(
        tokenA.token,
        creatorB.address
      )
    ).to.equal(0);

    expect(
      await vault.claimable(
        tokenB.token,
        creatorA.address
      )
    ).to.equal(0);
  });

  it("prevents unauthorized accounts from accruing creator fees", async function () {
    const token = await createToken(
      creatorA,
      "Token A",
      "TKA"
    );

    await expect(
      vault
        .connect(owner)
        .accrueCreatorFee(
          token.token,
          creatorA.address,
          {
            value: ethers.parseEther("1"),
          }
        )
    ).to.be.revertedWithCustomError(
      vault,
      "OnlyRegisteredCurve"
    );
  });

  it("prevents double claim", async function () {
    const token = await createToken(
      creatorA,
      "Token A",
      "TKA"
    );

    await ethers.provider.send("hardhat_setBalance", [
      await vault.getAddress(),
      ethers.toBeHex(
        ethers.parseEther("10")
      ),
    ]);

    await ethers.provider.send("hardhat_impersonateAccount", [
      token.curve,
    ]);

    await fundCurve(token.curve);

    const curve = await ethers.getSigner(
      token.curve
    );

    await vault
      .connect(curve)
      .accrueCreatorFee(
        token.token,
        creatorA.address,
        {
          value: ethers.parseEther("0.25"),
        }
      );

    await ethers.provider.send("hardhat_stopImpersonatingAccount", [
      token.curve,
    ]);

    await vault
      .connect(creatorA)
      .claim(token.token);

    expect(
      await vault.claimable(
        token.token,
        creatorA.address
      )
    ).to.equal(0);

    await expect(
      vault
        .connect(creatorA)
        .claim(token.token)
    ).to.be.revertedWithCustomError(
      vault,
      "NoRewards"
    );
  });

  it("enforces 5 minute claim cooldown", async function () {
    const token = await createToken(
      creatorA,
      "Token A",
      "TKA"
    );

    await ethers.provider.send("hardhat_setBalance", [
      await vault.getAddress(),
      ethers.toBeHex(
        ethers.parseEther("10")
      ),
    ]);

    await ethers.provider.send("hardhat_impersonateAccount", [
      token.curve,
    ]);

    await fundCurve(token.curve);

    const curve = await ethers.getSigner(
      token.curve
    );

    await vault
      .connect(curve)
      .accrueCreatorFee(
        token.token,
        creatorA.address,
        {
          value: ethers.parseEther("0.10"),
        }
      );

    await ethers.provider.send("hardhat_stopImpersonatingAccount", [
      token.curve,
    ]);

    await vault
      .connect(creatorA)
      .claim(token.token);

    // Fee baru masuk setelah claim.
    await ethers.provider.send("hardhat_impersonateAccount", [
      token.curve,
    ]);

    await fundCurve(token.curve);

    await vault
      .connect(curve)
      .accrueCreatorFee(
        token.token,
        creatorA.address,
        {
          value: ethers.parseEther("0.05"),
        }
      );

    await ethers.provider.send("hardhat_stopImpersonatingAccount", [
      token.curve,
    ]);

    expect(
      await vault.claimable(
        token.token,
        creatorA.address
      )
    ).to.equal(
      ethers.parseEther("0.05")
    );

    await expect(
      vault
        .connect(creatorA)
        .claim(token.token)
    ).to.be.revertedWithCustomError(
      vault,
      "ClaimCooldown"
    );

    // Lewati 5 menit.
    await ethers.provider.send("evm_increaseTime", [
      5 * 60,
    ]);

    await ethers.provider.send("evm_mine");

    await vault
      .connect(creatorA)
      .claim(token.token);

    expect(
      await vault.claimable(
        token.token,
        creatorA.address
      )
    ).to.equal(0);
  });

  it("BUY sends creator tax to CreatorFeeVault", async function () {
    const tokenData = await createToken(
      creatorA,
      "Buy Fee Token",
      "BFT",
      200
    );

    const curve = await ethers.getContractAt(
      "AelvoraBondingCurve",
      tokenData.curve
    );

    const buyAmount = ethers.parseEther("0.01");

    const quote = await curve.quoteBuy(buyAmount);

    console.log("DEBUG BUY:");
    console.log("  tokenReserve =", (await curve.tokenReserve()).toString());
    console.log("  tokensOut    =", quote.tokensOut.toString());
    console.log("  ethToCurve   =", quote.ethToCurve.toString());
    console.log("  creatorFee   =", quote.creatorFee.toString());

    expect(quote.creatorFee).to.equal(
      ethers.parseEther("0.0002")
    );

    await curve
      .connect(creatorB)
      .buy({ value: buyAmount });

    // createToken() already performed mandatory first-buy:
    // 0.001 ETH * 2% = 0.00002 ETH creator fee.
    //
    // The additional 0.01 ETH BUY adds:
    // 0.01 ETH * 2% = 0.0002 ETH.
    //
    // Total creator fee = 0.00022 ETH.
    expect(
      await vault.claimable(
        tokenData.token,
        creatorA.address
      )
    ).to.equal(ethers.parseEther("0.00022"));
  });

  it("SELL quote never exceeds real ETH reserve", async function () {
    const tokenData = await createToken(
      creatorA,
      "Liquidity Audit Token",
      "LAT",
      200
    );

    const curve = await ethers.getContractAt(
      "AelvoraBondingCurve",
      tokenData.curve
    );

    const buyAmount = ethers.parseEther("0.01");

    await curve
      .connect(creatorB)
      .buy({ value: buyAmount });

    const realEthReserve = await curve.ethReserve();

    const tokenContract = await ethers.getContractAt(
      "AelvoraToken",
      tokenData.token
    );

    const tokenBalance = await tokenContract.balanceOf(
      creatorB.address
    );

    const sellAmount = tokenBalance / 2n;

    const quote = await curve.quoteSell(sellAmount);

    console.log("DEBUG SELL:");
    console.log("  realEthReserve =", realEthReserve.toString());
    console.log("  ethGross       =", quote.ethGross.toString());
    console.log("  vaultBalance   =", (await ethers.provider.getBalance(await vault.getAddress())).toString());

    expect(quote.ethGross).to.be.lte(realEthReserve);
  });

  it("CURVE stress: virtual ETH never exceeds real ETH reserve", async function () {
    const tokenData = await createToken(
      creatorA,
      "Stress Token",
      "STRESS",
      200
    );

    const curve = await ethers.getContractAt(
      "AelvoraBondingCurve",
      tokenData.curve
    );

    const tokenContract = await ethers.getContractAt(
      "AelvoraToken",
      tokenData.token
    );

    // Multiple buys with different sizes.
    const buys = [
      ethers.parseEther("0.001"),
      ethers.parseEther("0.003"),
      ethers.parseEther("0.005"),
      ethers.parseEther("0.01"),
    ];

    for (const amount of buys) {
      const quote = await curve.quoteBuy(amount);

      expect(quote.tokensOut).to.be.gt(0);
      expect(quote.tokensOut).to.be.lt(
        await curve.tokenReserve()
      );

      await curve
        .connect(creatorB)
        .buy({ value: amount });
    }

    const realEthReserve = await curve.ethReserve();
    const tokenBalance = await tokenContract.balanceOf(
      creatorB.address
    );

    expect(realEthReserve).to.be.gt(0);
    expect(tokenBalance).to.be.gt(0);

    // Sell progressively smaller portions.
    const sellAmounts = [
      tokenBalance / 4n,
      tokenBalance / 4n,
      tokenBalance / 4n,
    ];

    for (const sellAmount of sellAmounts) {
      if (sellAmount == 0n) continue;

      const beforeReserve = await curve.ethReserve();
      const quote = await curve.quoteSell(sellAmount);

      expect(quote.ethGross).to.be.gt(0);
      expect(quote.ethGross).to.be.lte(beforeReserve);

      await tokenContract
        .connect(creatorB)
        .approve(tokenData.curve, sellAmount);

      await curve
        .connect(creatorB)
        .sell(sellAmount);

      const afterReserve = await curve.ethReserve();

      // The curve must never pay out more real ETH
      // than existed before the sale.
      expect(afterReserve).to.be.gte(0);
    }
  });

  it("CURVE supports creator-defined supply sizes", async function () {
    const supplies = [
      ethers.parseUnits("5674848", 18),
      ethers.parseUnits("100000", 18),
      ethers.parseUnits("1000000000", 18),
      ethers.parseUnits("1000000000000", 18),
    ];

    for (const supply of supplies) {
      const tx = await factory.connect(creatorA).createToken(
        "Supply Test",
        "SUP",
        supply,
        200,
        FIRST_BUY_ETH,
        {
          value: LAUNCH_FEE + FIRST_BUY_ETH,
        }
      );

      const receipt = await tx.wait();

      const event = receipt.logs
        .map((log) => {
          try {
            return factory.interface.parseLog(log);
          } catch {
            return null;
          }
        })
        .find(
          (event) => event && event.name === "TokenCreated"
        );

      const curve = await ethers.getContractAt(
        "AelvoraBondingCurve",
        event.args.curve
      );

      // Only 75% of total supply belongs to the
      // active bonding curve.
      const expectedCurveSupply =
        (supply * 7500n) / 10000n;

      // Remaining 25% is permanently reserved for
      // graduation / future Uniswap V4 LP.
      const expectedGraduationSupply =
        supply - expectedCurveSupply;

      const tokenContract =
        await ethers.getContractAt(
          "AelvoraToken",
          event.args.token
        );

      const currentCurveReserve =
        await curve.tokenReserve();

      const creatorBalance =
        await tokenContract.balanceOf(
          creatorA.address
        );

      const graduationReserve =
        await curve.graduationTokenReserve();

      // First-buy already removed tokens from the
      // active 75% curve inventory.
      expect(
        currentCurveReserve +
        creatorBalance
      ).to.equal(expectedCurveSupply);

      // The 25% graduation allocation must remain intact.
      expect(
        graduationReserve
      ).to.equal(expectedGraduationSupply);

      // Full supply accounting:
      //
      // remaining curve
      // + creator first-buy tokens
      // + graduation reserve
      // = total supply
      expect(
        currentCurveReserve +
        creatorBalance +
        graduationReserve
      ).to.equal(supply);

      const quote = await curve.quoteBuy(
        ethers.parseEther("0.01")
      );

      expect(quote.tokensOut).to.be.gt(0);
      expect(quote.tokensOut).to.be.lt(
        await curve.tokenReserve()
      );
    }
  });

  it("uses exactly 75% curve supply and 25% graduation reserve", async function () {
    const totalSupply = ethers.parseUnits("100000", 18);

    const tokenData = await createToken(
      creatorA,
      "75/25 Token",
      "SEVENTY",
      200
    );

    const curve = await ethers.getContractAt(
      "AelvoraBondingCurve",
      tokenData.curve
    );

    const expectedCurve =
      (totalSupply * 7500n) / 10000n;

    const expectedGraduation =
      totalSupply - expectedCurve;

    const tokenContract =
      await ethers.getContractAt(
        "AelvoraToken",
        tokenData.token
      );

    const currentCurveReserve =
      await curve.tokenReserve();

    const creatorTokenBalance =
      await tokenContract.balanceOf(
        creatorA.address
      );

    // First-buy already removed tokens from active
    // bonding-curve inventory.
    expect(
      currentCurveReserve +
      creatorTokenBalance
    ).to.equal(expectedCurve);

    // 25% graduation reserve is untouched.
    expect(
      await curve.graduationTokenReserve()
    ).to.equal(expectedGraduation);

    const allocation =
      await curve.supplyAllocation();

    // activeCurveTokens represents the CURRENT active
    // bonding-curve inventory after the mandatory first-buy.
    //
    // The original 75% allocation is:
    //   expectedCurve
    //
    // After first-buy:
    //   currentCurveReserve < expectedCurve
    //
    // Therefore activeCurveTokens must match the
    // current active curve reserve, not the initial allocation.
    expect(allocation.activeCurveTokens).to.equal(
      currentCurveReserve
    );

    // Graduation reserve remains untouched at exactly 25%
    // of the creator-defined total supply.
    expect(allocation.graduationTokens).to.equal(
      expectedGraduation
    );
  });

  it("keeps 25% graduation reserve outside active curve math", async function () {
    const totalSupply = ethers.parseUnits("100000", 18);

    const tokenData = await createToken(
      creatorA,
      "Reserve Isolation Token",
      "RIT",
      200
    );

    const curve = await ethers.getContractAt(
      "AelvoraBondingCurve",
      tokenData.curve
    );

    const curveReserve =
      await curve.tokenReserve();

    const graduationReserve =
      await curve.graduationTokenReserve();

    const tokenContract =
      await ethers.getContractAt(
        "AelvoraToken",
        tokenData.token
      );

    const creatorTokenBalance =
      await tokenContract.balanceOf(
        creatorA.address
      );

    expect(
      curveReserve +
      creatorTokenBalance +
      graduationReserve
    ).to.equal(totalSupply);

    // Initial curve math must use only the 75% allocation.
    const quote = await curve.quoteBuy(
      ethers.parseEther("0.001")
    );

    expect(quote.tokensOut).to.be.gt(0);
    expect(quote.tokensOut).to.be.lt(curveReserve);

    // The 25% graduation reserve is not part of
    // tokenReserve and therefore cannot be bought
    // through the active curve inventory.
    expect(graduationReserve).to.equal(
      (totalSupply * 2500n) / 10000n
    );
  });


  it("GRADUATION allows final buy to overshoot 3 ETH target", async function () {
    const tokenData = await createToken(
      creatorA,
      "Graduation Overshoot Token",
      "GOV"
    );

    const curve = await ethers.getContractAt(
      "AelvoraBondingCurve",
      tokenData.curve
    );

    // Mandatory first-buy already contributed:
    // 0.001 ETH gross
    // - 1% platform fee
    // - 2% creator tax
    // = 0.00097 ETH real curve reserve.
    const initialReserve =
      await curve.ethReserve();

    expect(initialReserve).to.equal(
      ethers.parseEther("0.00097")
    );

    expect(await curve.graduated()).to.equal(false);

    /*
     * Buy enough ETH so the curve crosses the
     * 3 ETH graduation threshold.
     *
     * IMPORTANT:
     * The final transaction is NOT required to land
     * exactly at 3 ETH.
     *
     * If the transaction takes the reserve from:
     *
     *   2.9 ETH -> 3.2 ETH
     *
     * it must still succeed.
     */
    const buyEth = ethers.parseEther("3.2");

    const quote = await curve.quoteBuy(buyEth);

    expect(quote.tokensOut).to.be.gt(0);

    await curve
      .connect(creatorB)
      .buy({
        value: buyEth,
      });

    const finalReserve =
      await curve.ethReserve();

    /*
     * Graduation must happen once the real curve
     * ETH reserve reaches/exceeds 3 ETH.
     */
    expect(finalReserve).to.be.gte(
      ethers.parseEther("3")
    );

    expect(await curve.graduated()).to.equal(true);

    /*
     * Most important assertion:
     *
     * The final buy was NOT reverted merely because
     * it pushed the reserve above 3 ETH.
     */
    expect(finalReserve).to.be.gt(
      ethers.parseEther("3")
    );
  });


  it("MIGRATION freezes curve and snapshots actual overshoot assets", async function () {
    const tokenData = await createToken(
      creatorA,
      "Migration Test Token",
      "MIG"
    );

    const curve = await ethers.getContractAt(
      "AelvoraBondingCurve",
      tokenData.curve
    );

    // Final buy deliberately overshoots the 3 ETH target.
    await curve
      .connect(creatorB)
      .buy({
        value: ethers.parseEther("3.2"),
      });

    expect(await curve.graduated()).to.equal(true);
      expect(await curve.migrationStarted()).to.equal(true);
    expect(await curve.migrationCompleted()).to.equal(false);

    const actualEthReserve =
      await curve.ethReserve();

    const actualTokenReserve =
      await curve.tokenReserve();

    const graduationReserve =
      await curve.graduationTokenReserve();

    const expectedMigrationTokens =
      actualTokenReserve +
      graduationReserve;

    expect(actualEthReserve).to.be.gt(
      ethers.parseEther("3")
    );


      // Migration snapshots the ACTUAL reserves.
      // ETH is not capped at the 3 ETH graduation target.
      // Tokens are active curve inventory + untouched
      // graduation reserve.
      expect(
        await curve.migrationEthAmount()
      ).to.equal(
        actualEthReserve
      );

      expect(
        await curve.migrationTokenAmount()
      ).to.equal(
        expectedMigrationTokens
      );

    /*
     * Once migration starts, bonding curve trading stops.
     */
    await expect(
      curve
        .connect(creatorB)
        .buy({
          value: ethers.parseEther("0.01"),
        })
    ).to.be.revertedWithCustomError(
      curve,
      "GraduationReached"
    );

    /*
     * Migration cannot be marked complete twice.
     * First completion is allowed at lifecycle level.
     */
    const factoryAddress = await factory.getAddress();

    await ethers.provider.send("hardhat_impersonateAccount", [
      factoryAddress,
    ]);
    await ethers.provider.send("hardhat_setBalance", [
      factoryAddress,
      "0x1000000000000000000",
    ]);
    const factorySigner = await ethers.getSigner(factoryAddress);

    await curve
      .connect(factorySigner)
      .completeMigration();

    expect(await curve.migrationCompleted()).to.equal(true);

    await expect(
      curve.connect(factorySigner).completeMigration()
    ).to.be.revertedWithCustomError(
      curve,
      "MigrationAlreadyCompleted"
    );

    await ethers.provider.send("hardhat_stopImpersonatingAccount", [
      factoryAddress,
    ]);
  });

  it("SELL sends creator tax to CreatorFeeVault", async function () {
    const tokenData = await createToken(
      creatorA,
      "Sell Fee Token",
      "SFT",
      200
    );

    const curve = await ethers.getContractAt(
      "AelvoraBondingCurve",
      tokenData.curve
    );

    const buyAmount = ethers.parseEther("0.01");

    await curve
      .connect(creatorB)
      .buy({ value: buyAmount });

    const tokenContract = await ethers.getContractAt(
      "AelvoraToken",
      tokenData.token
    );

    const tokenBalance = await tokenContract.balanceOf(
      creatorB.address
    );

    const sellAmount = tokenBalance / 2n;

    const quote = await curve.quoteSell(sellAmount);

    const before = await vault.claimable(
      tokenData.token,
      creatorA.address
    );

    await tokenContract
      .connect(creatorB)
      .approve(tokenData.curve, sellAmount);

    await curve
      .connect(creatorB)
      .sell(sellAmount);

    const after = await vault.claimable(
      tokenData.token,
      creatorA.address
    );

    expect(after - before).to.equal(
      quote.creatorFee
    );
  });});
